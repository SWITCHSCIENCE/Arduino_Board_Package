I couldn't get the path to the tool to work, so I decided to put the tool binary (from the URL below) here.
https://github.com/adafruit/Adafruit_nRF52_Arduino
